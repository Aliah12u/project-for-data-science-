﻿
using Microsoft.ML.Transforms.Image;
using SkiaSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace problemWrapper3
{
    internal class wineInput
    {
        [ImageType(ImageSettings.imageHeight, ImageSettings.imageWidth)]
        public SKBitmap? Image { get; set; }
    }
}
