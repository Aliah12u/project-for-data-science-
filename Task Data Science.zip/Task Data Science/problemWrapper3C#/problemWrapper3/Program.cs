﻿//using Google.Apis.YouTube.v3.Data;
using Microsoft.ML;
using SkiaSharp;
using System.Drawing;
using System;

using System.Drawing.Drawing2D;



namespace problemWrapper3 // Note: actual namespace depends on the project name.
{
    internal class Program
    {

        private static string[] testFiles = new[] { "./test/mask.jpg", "./test/withoutMash.jpg" };
        static void Main(string[] args)
        {


            SKBitmap testImage;
            var context = new MLContext();
            var emptyDate = new List<wineInput>();
            var data = context.Data.LoadFromEnumerable(emptyDate);
            var pipeline = context.Transforms.ResizeImages(resizing: Microsoft.ML.Transforms.Image.ImageResizingEstimator.ResizingKind.Fill,
                outputColumnName: "data", imageWidth: ImageSettings.imageWidth, imageHeight: ImageSettings.imageHeight,
                inputColumnName: nameof(wineInput.Image))
                .Append(context.Transforms.ExtractPixels(outputColumnName: "data"))
                .Append(context.Transforms.ApplyOnnxModel(modelFile: "./model/maskmodel.onnx", outputColumnName: "dense_1", inputColumnName: "conv2d_input"));
            var model = pipeline.Fit(data);
            var predictionEngine = context.Model.CreatePredictionEngine<wineInput, WinePrediction>(model);
            /*
            foreach (var image in testFiles)
            {
                //read path image
                FileStream file = new FileStream(image, FileMode.Open);
                //  var prediction = predictionEngine.Predict(new wineInput { Image = file });
            }
            */
            var labels = File.ReadAllLines("./Model/labels.txt");

            foreach (var image in testFiles)
            {
                using (var stream = new FileStream(image, FileMode.Open))
                {
                    testImage = (SKBitmap)Image.FromStream(stream);
                    var prediction = predictionEngine.Predict(new wineInput { Image = testImage });
                }
            }


        }
    
    }
        public struct ImageSettings
        {
            public const int imageHeight = 70;
            public const int imageWidth = 70;
        }
    
    
}