﻿using Microsoft.ML.Data;

namespace problemWrapper3
{
    internal class WinePrediction
    {
        [ColumnName("dense_1")]
        public float[] PredictedLabels { get; set; }    


    }
}