using System.Drawing.Text;

namespace problem4ImageGrayScale
{
    public partial class Form1 : Form
    {

        Bitmap bmpSelectImage, bmpGrayImage;

        int w, h;
        byte[,] Red; byte[,] Green; byte[,] Blue; byte[,] Gray;
        double mean = 0; double std = 0;
        int min = 0;
        int max = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog(this);
            bmpSelectImage = new Bitmap(openFileDialog1.FileName);
            pictureBox1.Image = bmpSelectImage;


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            w = bmpSelectImage.Width;
            h = bmpSelectImage.Height;
            Red = new byte[w, h];
            Green = new byte[w, h];
            Blue = new byte[w, h];
            Gray = new byte[w, h];
            bmpGrayImage = new Bitmap(w, h);


            Color p;
            for (int i = 0; i < w; i++)
            {
                for (int j = 0; j < h; j++)
                {

                    p = bmpSelectImage.GetPixel(i, j);

                    Red[i, j] = p.R;
                    Green[i, j] = p.G;
                    Blue[i, j] = p.B;
                    Gray[i, j] = (byte)((Red[i, j] + Green[i, j] + Blue[i, j]) / 3);
                    bmpGrayImage.SetPixel(i, j, Color.FromArgb(Gray[i, j], Gray[i, j], Gray[i, j]));

                }
            }
            pictureBox5.Image = bmpGrayImage;
        }


        private void meanImage(int w, int h, byte[,] Gray, ref double Mean)
        {

            for (int i = 0; i < w; i++)
            {
                for (int j = 0; j < h; j++)
                {
                    Mean = Mean + Gray[i, j];
                }

            }
            Mean = Mean / (double)(w * h);

        }


        private void standerdeviation(int w, int h, byte[,] Gray, double mean, ref double Graystd)
        {

            for (int i = 0; i < w; i++)
            {
                for (int j = 0; j < h; j++)
                {

                    Graystd += Math.Pow((Gray[i, j] - mean), 2);
                }
            }
            Graystd = Math.Sqrt(Graystd / (double)(w * h));

        }

        private void minimumValue(int w, int h, byte[,] Gray, ref int min)
        {

            for (int i = 0; i < w; i++)
            {
                for (int j = 0; j < h; j++)
                {
                    if (min > Gray[i, j])
                    {
                        min = Gray[i, j];
                    }
                }
            }

        }

        private void maximumValue(int w, int h, byte[,] Gray, ref int max)
        {

            for (int i = 0; i < w; i++)
            {
                for (int j = 0; j < h; j++)
                {
                    if (max < Gray[i, j])
                    {
                        max = Gray[i, j];
                    }
                }
            }



        }
        private void button4_Click(object sender, EventArgs e)
        {

            standerdeviation(w, h, Gray, mean, ref std);
            label2.Text = "the standerd deviation is " + std;
        }

        private void button5_Click(object sender, EventArgs e)
        {

            meanImage(w, h, Gray, ref mean);
            label1.Text = "the mean is " + mean;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            maximumValue(w, h, Gray, ref max);
            label4.Text = "The maximum value is :" + max;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            minimumValue(w, h, Gray, ref min);
            label3.Text = "the minimum is :" + min;
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }


    }
}