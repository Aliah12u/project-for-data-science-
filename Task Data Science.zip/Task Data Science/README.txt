

I use
 python version 3.10
 Tensorflow version 2.11
 Keras
 Onnx to convert model created in problem 2 and use problem3

 libriray   Keras  ,numpy ,pandas, opencv, sklearn ,matbitplot,  

im use ((jupter Notebook)) because is familier with python and data science





################  Problem 1 ##################
1 use opencv to read image and Drawing rectangle of face of any Image 
2 then show of plt




############### Problem 2 ###################


i build and train model then saved name (mymodel.h5)

1) download dataset in thins link and spilt data to train and testing
  
https://github.com/Aliah12u/dataOfProbelms


2)i'am use method ImageDataGenerator
to avoid overfiting when use princple data agumentation like rotate and resize image 
3)create model user Tensorflow and libriray kerars to build 
4) use cnn Convenola newor network for to use filter and more feauter about this layer of image 
5) optimizer data with adam and and loss binary_crossentropy 



################# problem3     ##################

the name model is maskmodel.onnx
1) i convert model from porble2 to (onnx)open neural network exchange 
2) and create code c# to predict 
and I encountered some problems, the solution to the question is incomplete


################ problem 4 #####################
1) create project c# 
2) you can select any picuter and convert grayScale 
to computing mean std  min and max 

#################   Problem5   ##############



how to run this code  click all of cell one by one 
and don't a click of cell model.fil of save because do'nt return training model


1) read dataset Price.csv
from libriray pandas  

2) check and clean dataset

3) convet DataFrame to numpy arrary to get number of rows to train and testing model

4) convert data to scaled data  to do best performance between data and to ease manuplute model of data

5) spilt dat to train data 80% and 20% to testing and predict 

5) spilt datat to x_train and y_train because ,i need use to train model LSTM(Long Short Term-memory) layer to

to train, i work x_train i give 60 days of arbitrry to predict next value and put in y_train 
for_example like that  x_train[1.2.3 ...59] --> y_train[value of (60)]
new input [2,3,4....60] --> new input[3,4,5...61] and so on

6)then reshape data x_tain and y_train because  3Di input LSTM model  take this shape
row ,steps and feauter(1)Price

7)build model it contain of LSTM layer it is cell from Rnn(recurrnt nerow network)
im use it to ML 

8)complie i'm ue optimizer adam for loss 'mean_squard_error'

9)fit data and create test data set 20% and splite to x_test and y_test
10) x_test to predict y_test is last 20% data not training
 to compaer between x_test and it
 11)predict x_test and rescale to compper withy_test
 12) use (rmse) to evalute root mean squared mean_squard_error
 13)